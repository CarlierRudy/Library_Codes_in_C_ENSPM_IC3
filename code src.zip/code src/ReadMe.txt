Project Name: Using a Library in C
Author: Rudy Carlier F
Date: 14th january 2025

*Description*
This project demonstrates how to create and use my own library in a C program.
The project includes a library file containing reusable functions, a header file, 
and a main program that calls the functions from the library.

*Architecture*
SampleLib.c => instructions of my function
SampleLib.h => a header file
main.c      =>  main programm where my library will be called 
